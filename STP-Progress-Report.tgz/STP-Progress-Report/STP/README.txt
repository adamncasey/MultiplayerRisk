Project for CS3099
Risk

Contributors:
Nathan Blades, nb48
Victor Andrei, va9
James Russel, jr79
Adam Casey, ac248

How to build the program:

ant

How to test the program:

ant test

How to run the program:

- ui test
java -cp "bin/RiskyBusiness.jar:lib/*" ui.Main

- game ui
java -cp "bin/RiskyBusiness.jar:lib/*" gameUI.Main

- Watch AIs play from command line
java -cp "bin/RiskyBusiness.jar:lib/*" main.WatchCLI

- Play on command line with AI
java -cp "bin/RiskyBusiness.jar:lib/*" main.PlayCLI
