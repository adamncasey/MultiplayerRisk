package networking;

import java.io.IOException;

public class ConnectionLostException extends IOException {
	
	private static final long serialVersionUID = -2837902819203315043L;

}
