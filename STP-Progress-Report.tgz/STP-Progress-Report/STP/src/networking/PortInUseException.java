package networking;

public class PortInUseException extends Exception {

	private static final long serialVersionUID = 7369502831402496824L;

}
