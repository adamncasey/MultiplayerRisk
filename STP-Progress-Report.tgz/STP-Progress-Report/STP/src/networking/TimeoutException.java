package networking;

public class TimeoutException extends Exception {
	
	private static final long serialVersionUID = 7307159415348426423L;

}
