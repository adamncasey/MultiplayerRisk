package networking.message;

/**
 * Created by Adam on 23/11/2014.
 */
public class MessageSignature {
    public String signMessage() {
        return "TBA";
    }
}
