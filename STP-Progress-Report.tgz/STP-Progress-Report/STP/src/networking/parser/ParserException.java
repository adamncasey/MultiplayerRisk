package networking.parser;

public class ParserException extends Exception {
    public ParserException(String message) {
        super(message);
    }
	/**
	 * 
	 */
	private static final long serialVersionUID = 5579321229793113562L;

}
